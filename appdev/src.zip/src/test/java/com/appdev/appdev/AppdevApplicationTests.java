package com.appdev.appdev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppdevApplicationTests {

	@Test
	void contextLoads() {
	}

}
