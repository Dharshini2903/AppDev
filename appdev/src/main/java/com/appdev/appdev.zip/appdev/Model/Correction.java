package com.appdev.appdev.Model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Correction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "attendance_log_id")
    private AttendanceLog attendanceLog;

    @ManyToOne
    @JoinColumn(name = "corrected_by_user_id")
    private User correctedByUser;

    private String reason;

    private LocalDateTime oldCheckIn;
    private LocalDateTime newCheckIn;

    private LocalDateTime oldCheckOut;
    private LocalDateTime newCheckOut;
}
