package com.appdev.appdev.Model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Column(unique = true, nullable = false)
    private String email;

    private String role; // USER, ADMIN, etc.
    @ManyToOne
    @JoinColumn(name = "manager_id")
    private User manager;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash; // only store the hash

     @Transient // not saved to DB, only used for input
    private String password;
}
