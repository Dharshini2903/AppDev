package com.appdev.appdev.Mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.appdev.appdev.Model.User;
import com.appdev.appdev.DTO.UserDTO;

@Mapper(componentModel = "spring")
public interface UserMapper {

    @Mapping(source = "manager.id", target = "managerId")
    UserDTO toDTO(User user);

    @Mapping(source = "managerId", target = "manager.id")
    User toEntity(UserDTO dto);
}
