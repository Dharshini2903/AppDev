package com.appdev.appdev.Mapper;

import org.mapstruct.Mapper;
import com.appdev.appdev.Model.Holiday;
import com.appdev.appdev.DTO.HolidayDTO;

@Mapper(componentModel = "spring")
public interface HolidayMapper {
    HolidayDTO toDTO(Holiday holiday);
    Holiday toEntity(HolidayDTO dto);
}
