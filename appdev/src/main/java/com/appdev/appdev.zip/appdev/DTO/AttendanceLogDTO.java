package com.appdev.appdev.DTO;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class AttendanceLogDTO {
    private Long id;

    @NotNull(message = "User ID is required")
    private Long userId;

    private LocalDateTime checkInTime;
    private LocalDateTime checkOutTime;
    private BigDecimal totalHours;
    private Boolean isCorrected;
}
