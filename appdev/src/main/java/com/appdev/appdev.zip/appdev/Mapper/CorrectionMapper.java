package com.appdev.appdev.Mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.appdev.appdev.Model.Correction;
import com.appdev.appdev.DTO.CorrectionDTO;

@Mapper(componentModel = "spring")
public interface CorrectionMapper {

    @Mapping(source = "attendanceLog.id", target = "attendanceLogId")
    CorrectionDTO toDTO(Correction correction);

    @Mapping(source = "attendanceLogId", target = "attendanceLog.id")
    Correction toEntity(CorrectionDTO dto);
}
