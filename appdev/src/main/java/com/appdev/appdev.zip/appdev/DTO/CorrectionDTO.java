package com.appdev.appdev.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CorrectionDTO {
    private Long id;

    @NotNull(message = "Attendance Log ID is required")
    private Long attendanceLogId;

    @NotBlank(message = "Reason is required")
    private String reason;
}
