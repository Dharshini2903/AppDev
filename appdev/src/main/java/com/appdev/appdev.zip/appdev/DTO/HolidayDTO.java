package com.appdev.appdev.DTO;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;

@Data
public class HolidayDTO {
    private Long id;

    @NotBlank(message = "Holiday name is required")
    private String name;

    @NotNull(message = "Date is required")
    @FutureOrPresent(message = "Holiday date must be today or in the future")
    private LocalDate date;
}
