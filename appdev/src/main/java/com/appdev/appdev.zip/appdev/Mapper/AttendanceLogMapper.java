package com.appdev.appdev.Mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.appdev.appdev.Model.AttendanceLog;
import com.appdev.appdev.DTO.AttendanceLogDTO;

@Mapper(componentModel = "spring")
public interface AttendanceLogMapper {

    @Mapping(source = "user.id", target = "userId")
    AttendanceLogDTO toDTO(AttendanceLog log);

    @Mapping(source = "userId", target = "user.id")
    AttendanceLog toEntity(AttendanceLogDTO dto);
}
