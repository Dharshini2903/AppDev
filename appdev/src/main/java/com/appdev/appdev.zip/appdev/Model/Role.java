package com.appdev.appdev.Model;

public enum Role {
    ADMIN,
    MANAGER,
    EMPLOYEE
}
