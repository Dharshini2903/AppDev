package com.appdev.appdev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppdevApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppdevApplication.class, args);
	}

}
